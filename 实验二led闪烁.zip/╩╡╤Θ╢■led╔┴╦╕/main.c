#include"reg51.h"
typedef unsigned char u8;
typedef unsigned int u16;
sbit led0=P2^1;   //D2
sbit led2=P2^3;   //D4
sbit led4=P2^5;   //D6
sbit led6=P2^7;   //D8
void delay(u16 i)
{
	while(i--);
}

void main()
{
	
	while(1)
	{
		led0=0;
		led2=0;
		led4=0;
		led6=0;
		
		delay(50000);		//450ms
		led0=1;
		led2=1;
		led4=1;
		led6=1;
		delay(50000);
	}
}