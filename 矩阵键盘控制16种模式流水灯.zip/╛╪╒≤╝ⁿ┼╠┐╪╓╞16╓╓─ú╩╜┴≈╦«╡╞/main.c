#define uchar unsigned char
#define uint unsigned int

#define GPIO_KEY P1
#define GPIO_DIG P0
sfr P2=0xa0;
sfr P1=0x90;
#define LED P2

uchar keyvalue;

void delay(uint i)
{
	while(i--);
}
void cr()
{
	uint i=0;
	while(1)
	{
		for(i=0;i<7;i++)
		{
			LED=((LED<<(8-1))|LED>>1);
			delay(50000);
		}
	}
}

void cl()
{
	uint i=0;
	while(1)
	{
		for(i=0;i<7;i++)
		{
			LED=((LED>>(8-1))|LED<<1);
			delay(50000);
		}
	}
}


void keydown()
{
	char a=0; 
	GPIO_KEY=0x0f;
	if(GPIO_KEY!=0x0f)//????????
	{
		delay(1000);//??10ms????
		if(GPIO_KEY!=0x0f)//??????????
		{
			//???
			GPIO_KEY=0x0f;
			switch(GPIO_KEY)
			{
				case(0x07):keyvalue=0;break;
				case(0x0b):keyvalue=1;break;
				case(0x0d):keyvalue=2;break;
				case(0x0e):keyvalue=3;break;
			}
			//???
			GPIO_KEY=0xf0;
			switch(GPIO_KEY)
			{
				case(0x70):keyvalue=keyvalue;break;
				case(0xb0):keyvalue=keyvalue+4;break;
				case(0xd0):keyvalue=keyvalue+8;break;
				case(0xe0):keyvalue=keyvalue+12;break;
			}
		
			while((a<50)&&(GPIO_KEY!=0xf0))//????????
			{
				delay(1000);
				a++;
			}
		}
	}
}

void main()
{
	while(1)
	{
		keydown();
		switch(keyvalue)
		{
			case(0):
				LED=0x7f;cr();break;
			case(1):
				LED=0x3f;cr();break;
			case(2):
				LED=0x1f;cr();break;
			case(3):
				LED=0x0f;cr();break;
			case(4):
				LED=0x07;cr();break;
			case(5):
				LED=0x03;cr();break;
			case(6):
				LED=0x01;cr();break;
			case(7):
				LED=0xfe;cl();break;			
			case(8):
				LED=0xfc;cl();break;
			case(9):
				LED=0xf8;cl();break;
			case(10):
				LED=0xf0;cl();break;
			case(11):
				LED=0xe0;cl();break;
			case(12):
				LED=0xc0;cl();break;
			case(13):
				LED=0x80;cl();break;
			case(14):
				{while(1){LED=0xe7;delay(50000);LED=0xdb;delay(50000);LED=0xbd;delay(50000);}break;}
			case(15):
				{while(1){LED=0xbd;delay(50000);LED=0xdb;delay(50000);LED=0xe7;delay(50000);}break;}
		}
	}
}