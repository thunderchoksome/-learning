#include"reg51.h"
#include"intrins.h"  //_crol_  _cror_ͷ�ļ�
typedef unsigned char u8;
typedef unsigned int u16;
#define A P2
void delay(u16 i)
{
	while(i--);
}

void main()
{
	u8 i;
	A=0xfe;//1111 1110
	delay(50000);
	while(1)
	{
		for(i=0;i<7;i++)
		{
		A=_crol_(A,1);
		delay(50000);		//450ms
		}
		for(i=0;i<7;i++)
		{
		A=_cror_(A,1);
		delay(50000);		//450ms
		}
		
	}
}