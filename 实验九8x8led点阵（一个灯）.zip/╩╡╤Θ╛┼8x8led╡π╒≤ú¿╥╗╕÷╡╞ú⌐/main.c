#include"reg51.h"
#include"intrins.h"

typedef unsigned char u8;
typedef unsigned int u16;

sbit RLCK=P3^5;
sbit SRLCK=P3^6;
sbit SER=P3^4;
void HC595Send(u8 data1)
{
	u8 i;
	SRLCK=0;
	RLCK=0;
	for(i=0;i<8;i++)
	{
		SER=data1>>7;
		data1<<=1;
		SRLCK=1;
		_nop_();
		_nop_();
		SRLCK=0;
	}
	RLCK=0;
	_nop_();
	_nop_();
	RLCK=1;
}
void main()
{
	P0=0x7f;
	while(1)
	{
		HC595Send(0x80);
	}
	
	
}