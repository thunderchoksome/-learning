#include"reg51.h"

typedef unsigned char u8;
typedef unsigned int u16;
sbit lsa=P2^2;
sbit lsb=P2^3;
sbit lsc=P2^4;
u8 code smgnum[]={0x3f  , 0x06 , 0x5b , 0x4f , 0x66 , 0x6d,0x7d , 0x07 , 0x7f  , 0x6f , 0x77 , 0x7c,
									0x39 , 0x5e , 0x79 , 0x71 , 0x00};

void main()
{
	lsa=0;
	lsb=0;
	lsc=0;
	P0=smgnum[0];
	while(1);
	
	
}