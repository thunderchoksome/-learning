#include"reg51.h"

sbit led0=P2^0;
sbit led1=P2^1;
void main()
{
	while(1)
	{
		led0=0;
		led1=0;
	}
}