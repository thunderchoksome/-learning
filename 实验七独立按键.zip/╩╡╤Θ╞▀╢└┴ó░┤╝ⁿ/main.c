#include"reg51.h"
typedef unsigned char u8;
typedef unsigned int u16;
sbit led0=P2^1;   //D2
sbit key1=P3^0;
void delay(u16 i)
{
	while(i--);
}
void keydown()
{
	if (key1==0)
	{
		delay(1000);
		if (key1==0)
		{
			led0=~led0;
		}
		while (!key1);
	}
}
void main()
{
	
	while(1)
	{
		keydown();
	}
}