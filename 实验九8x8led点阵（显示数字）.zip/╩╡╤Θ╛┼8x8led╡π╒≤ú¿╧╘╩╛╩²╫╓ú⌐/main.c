#include"reg51.h"
#include"intrins.h"

typedef unsigned char u8;
typedef unsigned int u16;
u8 ledduan[]={0x00,0x00,0x3e,0x41,0x41,0x41,0x3e,0x00};
u8 ledwait[]={0x7f,0xbf,0xdf,0xef,0xf7,0xfb,0xfd,0xfe};
sbit RLCK=P3^5;
sbit SRLCK=P3^6;
sbit SER=P3^4;
void delay(u16 i)
{
	while(i--);
}
void HC595Send(u8 data1)
{
	u8 i;
	SRLCK=0;
	RLCK=0;
	for(i=0;i<8;i++)
	{
		SER=data1>>7;
		data1<<=1;
		SRLCK=1;
		_nop_();
		_nop_();
		SRLCK=0;
	}
	RLCK=0;
	_nop_();
	_nop_();
	RLCK=1;
}
void main()
{
	u8 i;
	
	while(1)
	{
		P0=0x7f;
		for(i=0;i<8;i++)
		{
			P0=ledwait[i];
			HC595Send(ledduan[i]);
			delay(100);
			HC595Send(0x00);
		}
		
		
		
	}
	
	
}